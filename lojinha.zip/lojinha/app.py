from janela_principal import janela_principal_tk

if __name__ == "__main__":
    janela_principal_tk()